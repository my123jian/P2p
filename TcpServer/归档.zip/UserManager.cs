﻿using System;
namespace TcpServer
{
    public class UserManager
    {
        public UserManager()
        {
        }
    }
}
