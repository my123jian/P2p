﻿using System;
namespace TcpServer
{
    public class ClientServer
    {
        public ClientServer()
        {
        }
    }
}
